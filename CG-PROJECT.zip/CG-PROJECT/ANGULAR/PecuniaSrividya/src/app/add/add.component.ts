import { Component, OnInit } from '@angular/core';
import { SAccountService ,AccountBean } from '../s-account.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms'
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  user: AccountBean = new AccountBean(0,"",0,"","","","","","",0,0); 
                                                
  constructor(private accountService: SAccountService,private router: Router) { }
  ngOnInit() {
  }

   addAccount(): void {
    alert("Account created successfully");
     this.accountService.addAccount(this.user).subscribe( data => { 
      });
     
      }
  
}
