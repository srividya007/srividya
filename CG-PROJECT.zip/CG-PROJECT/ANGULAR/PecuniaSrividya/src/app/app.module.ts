import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListComponent } from './list/list.component';
import { UpdateComponent } from './update/update.component';
import { AddComponent } from './add/add.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { SAccountService } from './s-account.service';

@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    UpdateComponent,
    AddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,SAccountService],
  bootstrap: [AppComponent]
})
export class AppModule { }
