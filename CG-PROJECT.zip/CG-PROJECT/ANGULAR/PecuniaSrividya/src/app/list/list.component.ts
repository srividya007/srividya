import { Component, OnInit, Input } from '@angular/core';
import { SAccountService ,AccountBean} from '../s-account.service';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms'
import { UpdateComponent } from '../update/update.component';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  
  users: AccountBean[];
  constructor(private accountService:SAccountService,private router:Router) { }

  ngOnInit(): void {
    this.accountService.viewAll().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }
  handleSuccessfulResponse(response)
  {
      this.users=response;
  }
  deleteAccount(user: AccountBean): void {
    this.accountService.deleteAccount(user)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);});
        alert("account deleted successfully ");
}
  updateAccount(user: AccountBean): void {
        console.log(user)
        sessionStorage.setItem('accNumber',JSON.stringify(user))
        this.router.navigate(['update-pecunia'])
}
  }


