import { TestBed } from '@angular/core/testing';

import { SAccountService } from './s-account.service';

describe('SAccountService', () => {
  let service: SAccountService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SAccountService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
