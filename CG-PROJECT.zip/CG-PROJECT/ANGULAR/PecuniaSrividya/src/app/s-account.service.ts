import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


export class AccountBean
{
  constructor(public accNumber:number,
    public customerName:string,
    public customerPhno:number,
    public accType:string,
    public customerAddress1:string,
    public customerAddress2:string,
    public city:string,
    public state:string,
    public country:string,
    public pincode:number,
    public balance:number, )
    {
    }
}
@Injectable({
  providedIn: 'root'
})
export class SAccountService {
  accounts: AccountBean[];
  constructor(private httpService:HttpClient)
  {}
  addAccount(account):Observable<AccountBean>
{
  console.log(account);
  return this.httpService.post<AccountBean>("http://localhost:9999/add",account);
}

   viewAll(){
        return this.httpService.get<AccountBean[]>("http://localhost:9999/viewall");
}
public deleteAccount(account) {
  return this.httpService.delete<AccountBean>("http://localhost:9999/delete/"+ account.accNumber);
}

public updateAccount(account):Observable<AccountBean>  {
  console.log(account.accNumber);
  return this.httpService.put<AccountBean>("http://localhost:9999/update/" + account.accNumber, account);
}
}