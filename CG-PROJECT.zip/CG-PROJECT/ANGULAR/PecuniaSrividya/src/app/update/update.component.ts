import { Component, OnInit,Input } from '@angular/core';
import { SAccountService ,AccountBean } from '../s-account.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {


  user:AccountBean;

  // user: AccountBean = new AccountBean(0," ",0," "," "," "," "," "," ",0,0); 
  id:any;
  users:any;

  constructor(private route: ActivatedRoute, private accountService :SAccountService) { }

  ngOnInit(): void {
    this.user=JSON.parse(sessionStorage.getItem('accNumber'))
    console.log(this.user)
    
  }

  
  updateAccount(): void {

    this.accountService.updateAccount(this.user).subscribe( data => { 
      alert("account updated successfully with Account Number is " +this.user.accNumber);});
    
       
       }
}

