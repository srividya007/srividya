package com.capg.pecunia.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capg.pecunia.entity.AddBean;

@Repository
@Transactional
public class AddDaoImpl implements IAddDao{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public AddBean addAccount(AddBean bean) {
		bean.setAccNumber(Long.parseLong(String.valueOf(Math.abs(new Random().nextLong())).substring(0,12)));
		entityManager.persist(bean);
		return bean;
	}

}