package com.capg.pecunia.dao;

import java.util.List;

import com.capg.pecunia.entity.AddBean;

public interface IAddDao {
	
	
	  public AddBean addAccount(AddBean bean);
	  
}