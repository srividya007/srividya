package com.capg.pecunia.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.pecunia.dao.IAddDao;
import com.capg.pecunia.entity.AddBean;


@Service
public class AddServiceImpl implements IAddService {
	
	 @Autowired
	 IAddDao addDao;
	
	 @Override
		public AddBean addAccount(AddBean bean) {
			
			return addDao.addAccount(bean);
		}
}
