package com.capg.pecunia.service;

import java.util.List;

import com.capg.pecunia.entity.AddBean;

public interface IAddService  {
	
	public AddBean addAccount(AddBean bean);
}

