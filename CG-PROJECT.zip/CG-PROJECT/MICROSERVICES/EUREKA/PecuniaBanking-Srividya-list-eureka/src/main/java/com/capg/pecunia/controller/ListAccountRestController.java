package com.capg.pecunia.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.pecunia.entity.ListBean;
import com.capg.pecunia.service.IAccountService;



@CrossOrigin(origins = "http://localhost:4200")
@RestController

public class ListAccountRestController {

	@Autowired
     IAccountService accountservice;
	
	@GetMapping("/viewall")   //GET:         
	public ResponseEntity<List<ListBean>> viewAll() {

		List<ListBean> list = accountservice.viewAll();
		return new ResponseEntity<List<ListBean>>(list,new HttpHeaders(),HttpStatus.OK);	
    }
	/*
	 * public ResponseEntity<List<ListBean>> whengetnotwork() { return null; }
	 */

}
