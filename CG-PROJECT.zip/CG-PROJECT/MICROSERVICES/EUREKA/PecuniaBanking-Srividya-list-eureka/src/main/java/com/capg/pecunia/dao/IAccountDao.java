package com.capg.pecunia.dao;

import java.util.List;

import com.capg.pecunia.entity.ListBean;

public interface IAccountDao {
	
	
	  
	  public List<ListBean> viewAll();

	
	 
	 
}

