package com.capgemini.exception;

public class InvalidInput extends Exception {

	public InvalidInput(String s) {
		super(s);
	}
}
