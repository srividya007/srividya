package Team5_Pecunia_Bank.Management;

public @interface Test {

}
